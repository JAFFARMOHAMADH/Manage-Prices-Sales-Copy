/**Copyright(C)2009-2022SAPSEoranSAPaffiliatecompany.Allrightsreserved.*/
/**Copy of code from Standar Fiori App - F4111 Manage Prices - Sales */
sap.ui.define([
    "sap/ui/base/Object",
    "sap/ui/model/Filter",
    "sap/ui/model/FilterOperator"
],
    function (B, F, a) {
        "use strict";
        return B.extend("com.gpbp.zp2mpricelist.util.DynamicalAreaUtil",
            {
                aDefaultFilters: [
                    "FilterMethod",
                    "ConditionType",
                    "ConditionTable"
                ],
                aDefaultColumns: [
                    "ConditionType",
                    "ConditionTable",
                    "SoldToParty",
                    "SoldToPartyName",
                    "ShipToParty",
                    "ShipToPartyName",
                    "SalesOffice",
                    "SalesOfficeName",
                    "ShippingCondition",
                    "ShippingConditionName",
                    "Plant",
                    "PlantName",
                    "ConditionValidityEndDate",
                    "ConditionValidityStartDate",
                    "ConditionQuantity",
                    "ConditionQuantityUnit",
                    "ConditionRateAmount",
                    "ConditionCurrency"
                ],
                aOtherSelectedFilter: [],
                aKeyFields: [],
                aTypeTableKeyFields: [],
                aFilters: [],
                aColumns: [],
                aKeyFieldsFilters: [],
                oDataModel: undefined,
                sEntitySet: undefined,
                aKeyFieldsResult: [],
                aFilterFields: [],
                aKeyFieldsResultOld: [],

                constructor: function (s, S, b) {
                    this.oSmartFilterBar = s;
                    this.oNoteListManager = S;
                    this.oBusyModel = b;
                    this.aFilters = s.getAllFilterItems();
                    this.aColumns = S.getTable().getColumns();
                },

                // getKeyField: function () {
                //     returnthis.aFilterFields;
                // },

                setDataSource: function (d, e) {
                    this.oDataModel = d;
                    this.sEntitySet = e;
                },

                setFilterValues: function (f) {
                    this.aKeyFieldsFilters = [];

                    for (var x in f) {
                        if (f[x]) {
                            var b = [];
                            if (Array.isArray(f[x].values)) {
                                for (var y = 0; y < f[x].values.length; y++) {
                                    b.push(new F(f[x].name, a.EQ, f[x].values[y].key));
                                }
                            } else {
                                b.push(new F(f[x].name, a.EQ, f[x].values));
                            } this.aKeyFieldsFilters.push(new F({
                                filters: b,
                                and: false
                            }));
                        }
                    }
                },
                changeDynamicalArea: function (i, b, c) {
                    if (this.aKeyFieldsFilters.length !== 0) {
                        this.oDataModel.read(this.sEntitySet,
                            {
                                filters: this.aKeyFieldsFilters,
                                success: function (d) {
                                    this.aKeyFieldsResult = d.results; this.aKeyFields = [];
                                    this.aTypeTableKeyFields = [];
                                    this.aOtherSelectedFilter = [];

                                    for (var x in d.results) {
                                        if (d.results[x] && this.aKeyFields.indexOf(d.results[x].ConditionFieldName) === -1) {
                                            this.aKeyFields.push(d.results[x].ConditionFieldName);
                                        }
                                        var t = d.results[x].ConditionType + "," + d.results[x].ConditionTable + "," + d.results[x].ConditionFieldName;
                                        if (this.aTypeTableKeyFields.indexOf(t) === -1) {
                                            this.aTypeTableKeyFields.push(t);
                                        }
                                    }
                                    if (c) {
                                        this.aKeyFieldsResultOld = this.aKeyFieldsResult.concat();
                                        this.aFilterFields = this.aKeyFields.concat();
                                        if (this.oBusyModel.getProperty("/isBusy")) {
                                            this.oBusyModel.setProperty("/isBusy", false);
                                        }
                                        return;
                                    }

                                    this._resetFilterBar(b, i);
                                    this._hideColumn();

                                    if (i !== undefined) {
                                        this.oSmartFilterBar.search();
                                    }
                                    if (b) {
                                        this.oNoteListManager.rebindTable(true);
                                    }
                                    if (this.oBusyModel.getProperty("/isBusy") && b === undefined) {
                                        this.oBusyModel.setProperty("/isBusy", false);
                                    }
                                }.bind(this)
                            });
                    } else {
                        this._initFilterBar(c,
                            i);
                    }
                },
                _resetFilterBar: function (b,
                    I) {
                    if (b === undefined) {
                        this._resetFilterData(I);
                        this.aKeyFieldsResultOld = this.aKeyFieldsResult.concat();
                        this.aFilterFields = this.aKeyFields.concat();
                        for (var i in this.aFilters) {
                            if (this.aDefaultFilters.indexOf(this.aFilters[i].getName()) !== -1 || this.aKeyFields.indexOf(this.aFilters[i].getName()) !== -1 || this.aOtherSelectedFilter.indexOf(this.aFilters[i].getName()) !== -1) {
                                this.aFilters[i].setVisibleInAdvancedArea(true);
                                continue;
                            } else {
                                if (this.oBusyModel.getProperty("/isFeature") && this.aDefaultFeatureFilters.indexOf(this.aFilters[i].getName()) !== -1) {
                                    this.aFilters[i].setVisibleInAdvancedArea(true);
                                } else {
                                    this.aFilters[i].setVisibleInAdvancedArea(false);
                                }
                            }
                        }
                    } else {
                        for (i in this.aFilterFields) {
                            if (this.aKeyFields.indexOf(this.aFilterFields[i]) === -1) {
                                this.aKeyFields.push(this.aFilterFields[i]);
                            }
                        }
                        this.aKeyFieldsResult = this.aKeyFieldsResultOld.concat();
                    }
                },

                _resetFilterData: function (i) {
                    var f = Object.assign({},
                        this.oSmartFilterBar.getFilterData());
                    if (f !== undefined) {
                        var o = {};
                        if (f.ConditionRecord !== undefined) {
                            o.ConditionRecord = f.ConditionRecord;
                        } if (f.ValidOnDate !== undefined) {
                            o.ValidOnDate = f.ValidOnDate;
                        } if (f.ConditionType !== undefined) {
                            o.ConditionType = f.ConditionType;
                        } if (f.ConditionTable !== undefined) {
                            o.ConditionTable = f.ConditionTable;
                        }

                        for (var x in this.aKeyFields) {
                            if (f[this.aKeyFields[x]] !== undefined) {
                                o[this.aKeyFields[x]] = f[this.aKeyFields[x]];
                            }
                        }

                        for (x in this.aOptionalFilter) {
                            if (f[this.aOptionalFilter[x]] !== undefined) {
                                o[this.aOptionalFilter[x]] = f[this.aOptionalFilter[x]];
                                this.aOtherSelectedFilter.push(this.aOptionalFilter[x]);
                            }
                        }

                        // if (i === undefined) {
                        //     this.oSmartFilterBar._resetFilterFields();
                        //     this.oSmartFilterBar.setFilterData(o);
                        // }
                    }
                },

                _hideColumn: function () {
                    var f = [];
                    var s = "";
                    var b = false;
                    for (var m = 0; m < this.aColumns.length; m++) {
                        f = this.aColumns[m].getId().split("-");
                        s = f[f.length - 1];
                        for (var k in this.aDefaultColumns) {
                            if ((s === this.aDefaultColumns[k])) {
                                this.aColumns[m].setVisible(true);
                                b = true;
                                break;
                            } else {
                                b = false;
                            }
                        }

                        if (b) {
                            continue;
                        }

                        this.aColumns[m].setVisible(false);
                        for (var n in this.aKeyFields) {
                            if (s === this.aKeyFields[n]) {
                                this.aColumns[m].setVisible(true);
                                b = true;
                            }
                        }
                    }
                },

                _initFilterBar: function (i, I) {
                    this.aFilterFields = [];
                    this.aKeyFieldsResult = [];
                    this.aTypeTableKeyFields = [];
                    if (i) {
                        if (this.oBusyModel.getProperty("/isBusy")) {
                            this.oBusyModel.setProperty("/isBusy", false);
                        } return;
                    }

                    for (var e in this.aFilters) {
                        if (this.aFilters[e] && (this.aDefaultFilters.indexOf(this.aFilters[e].getName()) !== -1)) {
                            this.aFilters[e].setVisibleInAdvancedArea(true);
                            continue;
                        } else {
                            if (this.oBusyModel.getProperty("/isFeature") && this.aDefaultFeatureFilters.indexOf(this.aFilters[e].getName()) !== -1) {
                                this.aFilters[e].setVisibleInAdvancedArea(true);
                            } else {
                                this.aFilters[e].setVisibleInAdvancedArea(false);
                            }
                        }
                    }

                    for (var f in this.aColumns) {
                        if (this.aColumns[f]) {
                            this.aColumns[f].setVisible(true);
                        }
                    }

                    if (I !== undefined) {
                        if (this.oBusyModel.getProperty("/isBusy")) {
                            this.oBusyModel.setProperty("/isBusy", false);
                        } this.oSmartFilterBar.search(); return;
                    }

                    var o = Object.assign({}, this.oSmartFilterBar.getFilterData());

                    if (o !== undefined) {
                        var b = {};
                        if (o.ConditionRecord !== undefined) {
                            b.ConditionRecord = o.ConditionRecord;
                        }
                        if (o.ValidOnDate !== undefined) {
                            b.ValidOnDate = o.ValidOnDate;
                        }
                        // this.oSmartFilterBar._resetFilterFields();
                        // this.oSmartFilterBar.setFilterData(b);
                    }

                    if (this.oBusyModel.getProperty("/isBusy")) {
                        this.oBusyModel.setProperty("/isBusy", false);
                    }
                }
            });
    });