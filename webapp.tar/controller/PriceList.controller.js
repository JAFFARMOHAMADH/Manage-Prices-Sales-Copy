sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "com/gpbp/zp2mpricelist/util/DynamicalAreaUtil",
    "sap/m/MessageBox",
],
    /**
     * @param {typeof sap.ui.core.mvc.Controller} Controller
     */
    function (Controller, D, MessageBox) {
        "use strict";

        return Controller.extend("com.gpbp.zp2mpricelist.controller.PriceList", {
            onInit: function () {
                this._oSmartTable = this.byId("LineItemsSmartTable");
                this._oSmartFilterBar = this.byId("smartFilterBar");
                this._oBusyModel = new sap.ui.model.json.JSONModel({
                    isBusy: false
                });
                this.getView().setModel(this._oBusyModel, "busy");
                // this.oNavigationHandler = new N(this);
                // this.bOnInitFinished = true;
                // this.initAppState();
            },

            // onInitSmartFilterBar: function (e) {
            //     this.bFilterBarInitialized = true;
            //     this.initAppState();
            //     var b = this._oSmartFilterBar.getAllFilterItems();
            //     for (var i in b) {
            //         if (b[i].getGroupName() === "DraftAdministrativeData" || b[i].getName() === "ConditionIsExclusive") {
            //             b[i].setVisible(false);
            //         }
            //     }
            //     // this._oSmartFilterBar.getControlByKey("ConditionType").attachTokenUpdate(this._onTypeTokenUpdate, this);
            //     // this._oSmartFilterBar.getControlByKey("ConditionTable").attachTokenUpdate(this._onTableTokenUpdate, this);
            //     this._oConditionTypeFilter = {};
            //     this._oConditionTableFilter = {};
            // },

            // onInitSmartTable: function (e) {
            //  var c = ["ConditionValidityStartDate", "ConditionValidityEndDate", "ConditionQuantity", "ConditionReleaseStatus", "ConditionText", "PaymentTerms", "FixedValueDate", "AdditionalValueDays", "ConditionToBaseQtyNmrtr", "ConditionToBaseQtyDnmntr", "BaseUnit", "ConditionCalculationType", "ConditionRecord", "PrevApprovedConditionRecord", "SalesPriceApprovalRequest", "Status"];
            //  var s = ["PaymentTerms", "FixedValueDate", "AdditionalValueDays", "ConditionToBaseQtyNmrtr", "ConditionText", "ConditionToBaseQtyDnmntr", "BaseUnit", "ConditionCalculationType", "ConditionRecord", "SalesPriceApprovalRequest", "ConditionReleaseStatus", "ConditionQuantity", "ConditionTable"];
            // var u = this._oSmartTable.getUiState();
            // var p = u.getPresentationVariant();
            // var v = p.Visualizations[0];
            // v.Content = [];
            // var t = [];
            // var C = this._oTable.getColumns();
            // for (var m = 0; m < C.length; m++) {
            //     var b = C[m].getId().split("-");
            //     var d = b[b.length - 1];
            //     if (d === "Status") {
            //         C[m].setTemplate(this.oTemplate);
            //         C[m].setShowSortMenuEntry(false);
            //     } else if (s.indexOf(d) !== -1) {
            //         C[m].setShowSortMenuEntry(false);
            //     }
            //     t.push(d);
            //     if (c.indexOf(d) === -1) {
            //         var V = {};
            //         V.Value = d;
            //         v.Content.push(V);
            //     }
            // }
            // var I = this._oSmartTable.getIgnoreFromPersonalisation().split(",");
            // for (var i in this._oSmartTable._aColumnKeys) {
            //     if (t.indexOf(this._oSmartTable._aColumnKeys[i]) !== -1 || I.indexOf(this._oSmartTable._aColumnKeys[i]) !== -1 || this._oSmartTable._aColumnKeys[i] === "conditionAmountRatio" || this._oSmartTable._aColumnKeys[i] === "lowerAmountRatio" || this._oSmartTable._aColumnKeys[i] === "upperAmountRatio") {
            //         continue;
            //     } else {
            //         t.push(this._oSmartTable._aColumnKeys[i]);
            //         var o = {};
            //         o.Value = this._oSmartTable._aColumnKeys[i];
            //         v.Content.push(o);
            //     }
            // }
            // for (var n = 0; n < c.length; n++) {
            //     var g = {};
            //     g.Value = c[n];
            //     v.Content.push(g);
            //     if (c[n] === "ConditionValidityEndDate") {
            //         g = {};
            //         g.Value = "conditionAmountRatio";
            //         v.Content.push(g);
            //     } else if (c[n] === "ConditionReleaseStatus") {
            //         g = {};
            //         g.Value = "lowerAmountRatio";
            //         v.Content.push(g);
            //         g = {};
            //         g.Value = "upperAmountRatio";
            //         v.Content.push(g);
            //     }
            // }
            // this._oSmartTable.setUiState(u);
            // this.iRowHeight = this._oTable._getBaseRowHeight();
            //     this.bTableInitialized = true;
            //     this.initAppState();
            // },

            // initAppState: function () {
            //     if (!(this.bFilterBarInitialized && this.bOnInitFinished && this.bTableInitialized)) {
            //         return;
            //     }
            //     var p = this.oNavigationHandler.parseNavigation();
            //     var t = this;
            //     p.done(function (A, u, n) {
            //         if (n !== sap.fe.navigation.NavType.initial) {
            // var h = A && A.bNavSelVarHasDefaultsOnly;
            // var s = new S(A.selectionVariant);
            // var b = s.getParameterNames().concat(s.getSelectOptionsPropertyNames());
            // if (n === sap.fe.navigation.NavType.URLParams && b.length === 1 && b[0] === "openMode") {
            //     return;
            // }
            // var o = sap.ushell.Container.getService("URLParsing");
            // var H = o.getHash(window.location.href);
            // var c = H.indexOf("ConditionTables");
            // var C = H.indexOf("ConditionTypes");
            // if (c !== -1 && C !== -1) {
            //     if (n === sap.fe.navigation.NavType.URLParams) {
            //         var T = this._refactorSelectionVariant(b, s, A);
            //         b = T;
            //     }
            //     this._disableUIFunction();
            // }
            // var m = {
            //     replace: true,
            //     strictMode: false
            // };
            // var d = new U({
            //     selectionVariant: JSON.parse(A.selectionVariant),
            //     valueTexts: A.valueTexts,
            //     semanticDates: A.semanticDates ? JSON.parse(A.semanticDates) : {}
            // });
            // for (var i = 0; i < b.length; i++) {
            //     t._oSmartFilterBar.addFieldToAdvancedArea(b[i]);
            // }
            // if (!h || t._oSmartFilterBar.getCurrentVariantId() === "") {
            //     t._oSmartFilterBar.clearVariantSelection();
            //     t._oSmartFilterBar.clear();
            //     t._oSmartFilterBar.setUiState(d, m);
            // }
            // if ((A.customData && !A.customData.filterBarVariantDirty) || (h && t._oSmartFilterBar.getCurrentVariantId() === "")) {
            //     if (t._oSmartFilterBar.isPending()) {
            //         t._oSmartFilterBar.attachEventOnce("pendingChange", function () {
            //             t.byId("pageVariantId").currentVariantSetModified(false);
            //         });
            //     } else {
            //         t.byId("pageVariantId").currentVariantSetModified(false);
            //     }
            // }
            // if (A.tableVariantId) {
            //     t._oSmartTable.setCurrentVariantId(A.tableVariantId);
            // }
            // if (A.customData && A.customData.tablePresentationVariant) {
            //     var e = new U({
            //         selectionVariant: JSON.parse(A.customData.tableSelectionVariant),
            //         presentationVariant: JSON.parse(A.customData.tablePresentationVariant)
            //     });
            //     t._oSmartTable.setUiState(e);
            // }
            //     if (A.tableVariantId === undefined || A.tableVariantId === "") {
            //         this._setFilterFromRestore(A);
            //         this._oDynamicalAreaUtil.changeDynamicalArea(true);
            //     } else if (!h) {
            //         this._oSmartFilterBar.search();
            //     }
            // }
            // if (n === sap.fe.navigation.NavType.initial || h) {
            //     this.hidePlaceholderOnAppStart();
            // }
            //     }.bind(this));
            //     p.fail(function (e) {
            //         if (t.oPlaceholderContainer) {
            //             t.oPlaceholderContainer.hidePlaceholder();
            //         }
            //         t._handleError(e);
            //     });
            // },

            // _setFilterFromRestore: function (A) {
            //     if (A.oSelectionVariant !== undefined) {
            //         this.aTypes = [];
            //         this.aTables = [];
            //         if (A.oSelectionVariant.getSelectOption("ConditionType") !== undefined) {
            //             for (var m = 0; m < A.oSelectionVariant.getSelectOption("ConditionType").length; m++) {
            //                 this.aTypes.push({
            //                     key: A.oSelectionVariant.getSelectOption("ConditionType")[m].Low
            //                 });
            //             }
            //         }
            //         if (A.oSelectionVariant.getSelectOption("ConditionTable") !== undefined) {
            //             for (var t = 0; t < A.oSelectionVariant.getSelectOption("ConditionTable").length; t++) {
            //                 this.aTables.push({
            //                     key: A.oSelectionVariant.getSelectOption("ConditionTable")[t].Low
            //                 });
            //             }
            //         }
            //         this._oBusyModel.setProperty("/isBusy", true);
            //         this._createDynamicaAreaUtil();
            //         if (this.aTypes.length > 0) {
            //             if (this.aTables.length > 0) {
            //                 this._oDynamicalAreaUtil.setFilterValues([{
            //                     "name": "ConditionType",
            //                     "values": this.aTypes
            //                 }, {
            //                     "name": "ConditionTable",
            //                     "values": this.aTables
            //                 }]);
            //             } else {
            //                 this._oDynamicalAreaUtil.setFilterValues([{
            //                     "name": "ConditionType",
            //                     "values": this.aTypes
            //                 }]);
            //             }
            //         } else {
            //             if (this.aTables.length > 0) {
            //                 this._oDynamicalAreaUtil.setFilterValues([{
            //                     "name": "ConditionTable",
            //                     "values": this.aTables
            //                 }]);
            //             } else {
            //                 this._oDynamicalAreaUtil.setFilterValues();
            //             }
            //         }
            //     }
            // },

            // Event to generate dynamic area at variant load
            onSFBAfterVariantLoad: function (e) {
                this._createDynamicaAreaUtil();
                this._oDynamicalAreaUtil.aKeyFieldsResult = [];
                var c = e.getSource().getFilterData().ConditionType;
                if (c !== undefined) {
                    if (this._onGetFilterType(c)) {
                        return;
                    }
                } else {
                    this.aTypes = [];
                }
                var C = e.getSource().getFilterData().ConditionTable;
                if (C !== undefined) {
                    if (this._onGetFilterTable(C)) {
                        return;
                    }
                } else {
                    this.aTables = [];
                }
                if (this.aTypes.length > 0) {
                    if (this.aTables.length > 0) {
                        this._oDynamicalAreaUtil.setFilterValues([{
                            "name": "ConditionType",
                            "values": this.aTypes
                        }, {
                            "name": "ConditionTable",
                            "values": this.aTables
                        }]);
                    } else {
                        this._oDynamicalAreaUtil.setFilterValues([{
                            "name": "ConditionType",
                            "values": this.aTypes
                        }]);
                    }
                } else {
                    if (this.aTables.length > 0) {
                        this._oDynamicalAreaUtil.setFilterValues([{
                            "name": "ConditionTable",
                            "values": this.aTables
                        }]);
                    } else {
                        this._oDynamicalAreaUtil.setFilterValues();
                    }
                }
                this._oDynamicalAreaUtil.changeDynamicalArea(undefined, undefined, true);
            },

            //function invokes when any filter values changed
            onFilterChange: function (oEvent) {
                if (oEvent.getParameter("afterFilterDataUpdate") || oEvent.getParameter("sId") === "valueListChanged" || oEvent.getParameter("mParameters") === undefined) {
                    return;
                }

                var i = oEvent.getParameter("mParameters").id.toString().search("ConditionType"),
                    I = oEvent.getParameter("mParameters").id.toString().search("ConditionTable");

                this.aTypes = [];
                this.aTables = [];
                if (i !== -1 || I !== -1) {
                    this._createDynamicaAreaUtil();
                    var o = oEvent.getParameter("oSource");
                    var n = this.getView().getModel("i18n").getResourceBundle().getText("filterNotSupported");
                    if (o.getValueStateText() === n) {
                        o.setValueState("None");
                        o.setValueStateText("");
                    } else if (o.getValueState() === "Error") {
                        return;
                    }
                    this._buildDynamicFilter(o, i, I, n);
                }
            },

            // Private method to create dynamic area
            _createDynamicaAreaUtil: function () {
                if (!this._oDynamicalAreaUtil) {
                    this._oDynamicalAreaUtil = new D(this._oSmartFilterBar, this._oSmartTable, this._oBusyModel);
                    this._oDynamicalAreaUtil.setDataSource(this.getOwnerComponent().getModel(), "/I_SlsPrcgKeyCombinationField");
                }
            },

            // Private method to build dynamic filters
            _buildDynamicFilter: function (s, i, I, n) {
                var c = this._oSmartFilterBar.getFilterData().ConditionType;
                var C = this._oSmartFilterBar.getFilterData().ConditionTable;
                var r = false;
                if (c !== undefined) {
                    if (this._onGetFilterType(c)) {
                        if (c.ranges.length !== 0 && i !== -1) {
                            s.setValueState("Error");
                            s.setValueStateText(n);
                        }
                        r = true;
                    }
                    // if (c.value !== null) {
                    //     this._oConditionTypeFilter = {
                    //         source: s,
                    //         typeIndex: i,
                    //         tableIndex: I,
                    //         text: n
                    //     };
                    // }
                    if (C !== undefined) {
                        // if (C.value !== null) {
                        //     this._oConditionTableFilter = {
                        //         source: s,
                        //         typeIndex: i,
                        //         tableIndex: I,
                        //         text: n
                        //     };
                        // }

                        this.aTables.push({ key: C });
                        this._oBusyModel.setProperty("/isBusy", true);
                        this._oDynamicalAreaUtil.setFilterValues([{
                            "name": "ConditionType",
                            "values": this.aTypes
                        }, {
                            "name": "ConditionTable",
                            "values": this.aTables
                        }]);
                        this._oDynamicalAreaUtil.changeDynamicalArea();
                        this._removeErrorState();
                    } else {
                        if (r) {
                            return;
                        }
                        this.aTables.splice(0, this.aTables.length);
                        this._oBusyModel.setProperty("/isBusy", true);
                        this._oDynamicalAreaUtil.setFilterValues([{
                            "name": "ConditionType",
                            "values": this.aTypes
                        }]);
                        this._oDynamicalAreaUtil.changeDynamicalArea();
                        this._removeErrorState();
                    }
                } else {
                    this._processNoConditionType(s, C, I, n);
                }
            },

            _removeErrorState: function () {
                var t = this._oSmartFilterBar.getControlByKey("ConditionType");
                var T = this._oSmartFilterBar.getControlByKey("ConditionTable");
                if (t.getValueState() === "Error") {
                    t.setValue("");
                    t.setValueState("None");
                    t.setValueStateText("");
                }
                if (T.getValueState() === "Error") {
                    T.setValue("");
                    T.setValueState("None");
                    T.setValueStateText("");
                }
            },

            // Private method to get filter type
            _onGetFilterType: function (c) {
                var r = true;
                if (c.items.length === 0 && c.ranges.length === 0) {
                    return r;
                } else {
                    r = false;
                    this.aTypes.splice(0, this.aTypes.length);
                    for (var x = 0; x < c.items.length; x++) {
                        this.aTypes.push(c.items[x]);
                    }
                    for (var y = 0; y < c.ranges.length; y++) {
                        if (c.ranges[y].exclude === false && c.ranges[y].operation === "EQ") {
                            this.aTypes.push({
                                key: c.ranges[y].value1,
                                text: ""
                            });
                        } else {
                            this.aTypes = [];
                            r = true;
                            break;
                        }
                    }
                    return r;
                }
            },

            // Private method to process condition types
            _processNoConditionType: function (s, c, i, n) {
                if (this.aTypes.length > 0) {
                    this.aTypes.splice(0, this.aTypes.length);
                    this.aTables.splice(0, this.aTables.length);
                    this._oBusyModel.setProperty("/isBusy", true);
                    this._oDynamicalAreaUtil.setFilterValues();
                    this._oDynamicalAreaUtil.changeDynamicalArea();
                    this._removeErrorState();
                } else {
                    if (c !== undefined) {
                        // if (c.value !== null) {
                        //     this._oConditionTableFilter = {
                        //         source: s,
                        //         typeIndex: -1,
                        //         tableIndex: i,
                        //         text: n
                        //     };
                        // }

                        this.aTables.push({ key: c });
                        this._oBusyModel.setProperty("/isBusy", true);
                        this._oDynamicalAreaUtil.setFilterValues([{
                            "name": "ConditionTable",
                            "values": this.aTables
                        }]);
                        this._oDynamicalAreaUtil.changeDynamicalArea();
                        this._removeErrorState();
                    } else {
                        this.aTables.splice(0, this.aTables.length);
                        this._oBusyModel.setProperty("/isBusy", true);
                        this._oDynamicalAreaUtil.setFilterValues();
                        this._oDynamicalAreaUtil.changeDynamicalArea();
                        this._removeErrorState();
                    }
                }
            },

            // Event handler for Send Email to show approver details
            onEmail: function () {
                let oTable = this.getView().byId("LineItemsSmartTable");
                if (oTable.getTable().getSelectedIndices().length > 0) {
                    // get approver details
                    this._getApproversEmail();
                } else {
                    MessageBox.error(this._getText("selectRows"));
                }
            },

            // Event handler for Ok button press to send condition records in email
            onOkPress: function () {
                if (this.byId("idApproverCombo").getSelectedKeys().length > 0) {
                    this.byId("idApproverCombo").setValueState("None");

                    this.byId("_IDApproverDialog").close();
                    this.getView().setBusy(true);

                    //generating payload to send selected data
                    let aApprovers = [], aConditionRecords = [];
                    this.byId("idApproverCombo").getSelectedItems().forEach((item) => {
                        let oApprovers = {
                            name: item.getAdditionalText(),
                            type: "",
                            numb: "",
                            sign: "",
                            opti: "",
                            low: item.getKey(),
                            high: ""
                        };
                        aApprovers.push(oApprovers);
                    });

                    let oTable = this.getView().byId("LineItemsSmartTable"),
                        aIndices = oTable.getTable().getSelectedIndices();

                    aIndices.forEach((idx) => {
                        let oObject = oTable.getTable().getContextByIndex(idx).getObject();
                        delete oObject.__metadata;
                        aConditionRecords.push(oObject);
                    });

                    let oPayload = {
                        Dummy: "Dummy", // Dummy value to be passed as it is a key field
                        HDR_TVARVC: aApprovers,
                        HDR_ITEM: aConditionRecords
                    };

                    let oModel = this.getOwnerComponent().getModel();
                    oModel.create("/HeaderSet", oPayload, {
                        success: function (data) {
                            this.getView().setBusy(false);
                            MessageBox.success(this._getText("success"));
                            let oTable = this.getView().byId("LineItemsSmartTable");
                            oTable.getTable().clearSelection();
                        }.bind(this),

                        error: function (oError) {
                            this.getView().setBusy(false);
                            var sPattern = new RegExp("[{}]");
                            var sStrMatch = oError.responseText.match(sPattern);
                            if (sStrMatch) {
                                var sMsg = JSON.parse(oError.responseText);
                                MessageBox.error(sMsg.error.message.value);
                            } else {
                                MessageBox.error(oError.responseText);
                            }
                        }.bind(this)
                    });
                } else {
                    this.byId("idApproverCombo").setValueState("Error");
                    MessageBox.error(this._getText("seletcApprover"));
                }
            },

            // Event handler for Cancel button press to close dialog
            onCancelPress: function () {
                this.byId("_IDApproverDialog").close();
            },

            // private method which returns i18n labels
            _getText: function (param) {
                return this.getView().getModel("i18n").getResourceBundle().getText(param);
            },

            // private method to instatnitate Approvers dialog
            _getApproversEmail: function () {
                if (!this.pDialog) {
                    this.pDialog = this.loadFragment({
                        name: "com.gpbp.zp2mpricelist.fragment.Approvers"
                    });
                }
                this.pDialog.then(function (oDialog) {
                    oDialog.open();
                    this.byId("idApproverCombo").removeAllSelectedItems();
                }.bind(this));
            }
        });
    });
