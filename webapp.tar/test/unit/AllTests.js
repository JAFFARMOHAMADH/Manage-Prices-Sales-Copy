sap.ui.define([
	"comgpbp/zp2m_pricelist/test/unit/controller/App.controller"
], function () {
	"use strict";
});
