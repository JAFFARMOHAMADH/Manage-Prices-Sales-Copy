/* global QUnit */
QUnit.config.autostart = false;

sap.ui.getCore().attachInit(function () {
	"use strict";

	sap.ui.require([
		"comgpbp/zp2m_pricelist/test/unit/AllTests"
	], function () {
		QUnit.start();
	});
});
