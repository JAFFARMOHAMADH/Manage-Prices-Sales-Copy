/* global QUnit */

sap.ui.require(["com/gpbp/zp2mpricelist/test/integration/AllJourneys"
], function () {
	QUnit.config.autostart = false;
	QUnit.start();
});
